export declare class CookieService {
    /**
     *
     */
    static getCookieStringValue(cookieName: string): string | undefined;
}
